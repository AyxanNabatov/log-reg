﻿
namespace Service.DTO_s.Category
{
    public class CategoryDTO
    {
        public string? Name { get; set; }
    }
}
