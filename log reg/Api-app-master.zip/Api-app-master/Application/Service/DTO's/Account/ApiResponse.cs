﻿
namespace Service.DTO_s.Account
{
    public class ApiResponse
    {
        public List<string>? Errors { get; set; }
        public string? StatusMessage { get; set; }
    }
}
