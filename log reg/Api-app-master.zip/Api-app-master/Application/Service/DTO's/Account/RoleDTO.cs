﻿
namespace Service.DTO_s.Account
{
    public class RoleDTO
    {
        public string? Role { get; set; }
    }
}
